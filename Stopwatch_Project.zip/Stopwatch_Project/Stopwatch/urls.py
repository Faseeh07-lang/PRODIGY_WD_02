from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('start/', views.start_stopwatch, name='start_stopwatch'),
    path('stop/', views.stop_stopwatch, name='stop_stopwatch'),
    path('reset/', views.reset_stopwatch, name='reset_stopwatch'),
]