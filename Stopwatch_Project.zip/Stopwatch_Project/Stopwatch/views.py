from django.shortcuts import render, redirect
import time

# Global variables to store stopwatch state
start_time = None
elapsed_time = 0
is_running = False

def index(request):
    """Render the homepage with the stopwatch."""
    global elapsed_time, is_running
    current_time = elapsed_time
    if is_running:
        current_time = time.time() - start_time
    
    context = {
        'elapsed_time': format_time(current_time),
        'is_running': is_running
    }
    return render(request, 'stopwatch.html', context)

def start_stopwatch(request):
    """Start the stopwatch."""
    global start_time, is_running
    if not is_running:
        start_time = time.time() - elapsed_time  # Continue from where we left off
        is_running = True
    return redirect('index')

def stop_stopwatch(request):
    """Stop the stopwatch."""
    global elapsed_time, is_running
    if is_running:
        elapsed_time = time.time() - start_time
        is_running = False
    return redirect('index')

def reset_stopwatch(request):
    """Reset the stopwatch."""
    global start_time, elapsed_time, is_running
    start_time = None
    elapsed_time = 0
    is_running = False
    return redirect('index')

def format_time(seconds):
    """Format the elapsed time in hours:minutes:seconds.milliseconds."""
    hrs = int(seconds // 3600)
    mins = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    ms = int((seconds - int(seconds)) * 1000)
    return f'{hrs:02}:{mins:02}:{secs:02}.{ms:03}'

def index(request):
    """Render the homepage with the stopwatch."""
    global elapsed_time, is_running
    current_time = elapsed_time
    if is_running:
        current_time = time.time() - start_time
    
    context = {
        'elapsed_time': current_time,  # Send the raw number without formatting
        'is_running': is_running
    }
    return render(request, 'stopwatch.html', context)

